# Revenue Signals™ — by Kartik Clarity™

An executive revenue diagnostic application. Answer a short set of questions
about pipeline, forecasting, retention, process, data hygiene, and team
alignment, and Revenue Signals™ generates a scored, evidence-based report:

- Signal scoring (0–100) per category with Strong / Moderate / Weak verdicts
- Diagnostic confidence rating (completeness + verified evidence)
- Evidence summaries for every category
- Contradiction detection between related signals
- Blind spot detection (confident but unverified, or confirmed weak areas)
- Dollarized revenue exposure estimate
- Ranked priority actions with estimated recovery value
- Built-in Tool Finder matched to your weakest signals

## Tech stack

- React 19 + TypeScript
- Vite 7
- Tailwind CSS v4 (centralized brand color tokens in `src/index.css`)
- React Router (HashRouter, for static-hosting-safe routing)
- lucide-react icons

## Getting started

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

The production build is a static site (output in `dist/`) and can be hosted
on any static file host. Routing uses `HashRouter` so deep links such as
`/#/diagnostic` work correctly without any server-side rewrite rules.

## Project structure

```
src/
  brand/            Centralized brand constants (name, tagline, logo paths)
  components/        Header, Footer, Layout, Logo
  lib/               Diagnostic engine, question bank, tool finder dataset, types
  pages/             Home, Diagnostic, Report, Tool Finder, 404
  state/             Report context (session-persisted diagnostic result)
public/
  brand/             Official Kartik Clarity™ circle and wide logo assets
```

## Brand assets

The official Kartik Clarity™ logos live in `public/brand/`:

- `kartik-clarity-circle.png` — circle mark
- `kartik-clarity-wide.png` — wide/rectangle lockup

All brand colors are centralized as design tokens in `src/index.css` under
the `@theme` block (`--color-brand-*`, `--color-signal-*`). Do not introduce
new colors outside this system.

## Environment variables

This application currently runs entirely client-side and does not require
any secrets to build or run. See `.env.example` for the placeholder should
future integrations (e.g. a backend API) be added.
