// Kartik Clarity™ — centralized brand constants.
// Logos are official static assets. Do not replace with external URLs.
export const BRAND = {
  productName: "Revenue Signals™",
  companyName: "Kartik Clarity™",
  tagline: "Turn scattered revenue data into one clear verdict.",
  logoCircle: "/brand/kartik-clarity-circle.png",
  logoWide: "/brand/kartik-clarity-wide.png",
  supportEmail: "clarity@kartikclarity.com",
};

export const NAV_LINKS = [
  { label: "Home", to: "/" },
  { label: "Diagnostic", to: "/diagnostic" },
  { label: "Tool Finder", to: "/tool-finder" },
];
