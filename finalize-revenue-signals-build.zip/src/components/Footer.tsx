import { LogoCircle } from "./Logo";
import { BRAND, NAV_LINKS } from "../brand/constants";

export function Footer() {
  return (
    <footer className="border-t border-brand-slate-100 bg-brand-ink text-brand-slate-300">
      <div className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid gap-10 md:grid-cols-3">
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <LogoCircle className="h-9 w-9" />
              <span className="font-semibold text-white">{BRAND.productName}</span>
            </div>
            <p className="max-w-xs text-sm text-brand-slate-300">
              {BRAND.tagline} An executive diagnostic by {BRAND.companyName}.
            </p>
          </div>

          <div>
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-brand-gold-400">
              Navigate
            </h3>
            <ul className="space-y-2 text-sm">
              {NAV_LINKS.map((link) => (
                <li key={link.to}>
                  <a href={`#${link.to}`} className="hover:text-white">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-brand-gold-400">
              Contact
            </h3>
            <p className="text-sm">{BRAND.supportEmail}</p>
            <p className="mt-4 text-xs text-brand-slate-500">
              Revenue Signals™ and Kartik Clarity™ are trademarks of their respective owner.
            </p>
          </div>
        </div>

        <div className="mt-10 border-t border-white/10 pt-6 text-xs text-brand-slate-500">
          © {new Date().getFullYear()} {BRAND.companyName}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
