import { BRAND } from "../brand/constants";

export function LogoCircle({ className = "h-10 w-10" }: { className?: string }) {
  return (
    <img
      src={BRAND.logoCircle}
      alt={`${BRAND.companyName} circle logo`}
      className={`${className} rounded-full object-cover`}
    />
  );
}

export function LogoWide({ className = "h-10 w-auto" }: { className?: string }) {
  return (
    <img
      src={BRAND.logoWide}
      alt={`${BRAND.companyName} logo`}
      className={`${className} object-contain`}
    />
  );
}
