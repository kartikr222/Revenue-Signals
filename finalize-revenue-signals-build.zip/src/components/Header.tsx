import { NavLink } from "react-router-dom";
import { LogoWide } from "./Logo";
import { NAV_LINKS } from "../brand/constants";
import { useState } from "react";
import { Menu, X } from "lucide-react";

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-brand-slate-100 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <NavLink to="/" className="flex items-center gap-2 brand-focus" onClick={() => setOpen(false)}>
          <LogoWide className="h-9 w-auto sm:h-10" />
        </NavLink>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === "/"}
              className={({ isActive }) =>
                `rounded-full px-4 py-2 text-sm font-medium brand-focus transition-colors ${
                  isActive
                    ? "bg-brand-navy-50 text-brand-navy"
                    : "text-brand-slate-700 hover:bg-brand-slate-50 hover:text-brand-ink"
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
          <NavLink
            to="/diagnostic"
            className="ml-2 rounded-full bg-brand-navy px-5 py-2 text-sm font-semibold text-white shadow-sm brand-focus transition-colors hover:bg-brand-ink"
          >
            Run Diagnostic
          </NavLink>
        </nav>

        <button
          className="rounded-md p-2 text-brand-ink md:hidden brand-focus"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-brand-slate-100 bg-white px-6 py-4 md:hidden">
          <div className="flex flex-col gap-1">
            {NAV_LINKS.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === "/"}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  `rounded-lg px-4 py-3 text-base font-medium brand-focus ${
                    isActive
                      ? "bg-brand-navy-50 text-brand-navy"
                      : "text-brand-slate-700 hover:bg-brand-slate-50"
                  }`
                }
              >
                {link.label}
              </NavLink>
            ))}
            <NavLink
              to="/diagnostic"
              onClick={() => setOpen(false)}
              className="mt-2 rounded-lg bg-brand-navy px-4 py-3 text-center text-base font-semibold text-white"
            >
              Run Diagnostic
            </NavLink>
          </div>
        </div>
      )}
    </header>
  );
}
