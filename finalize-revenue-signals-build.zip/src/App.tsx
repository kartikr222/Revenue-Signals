import { HashRouter, Route, Routes } from "react-router-dom";
import { Layout } from "./components/Layout";
import { ReportProvider } from "./state/ReportContext";
import Home from "./pages/Home";
import Diagnostic from "./pages/Diagnostic";
import ToolFinder from "./pages/ToolFinder";
import Report from "./pages/Report";
import NotFound from "./pages/NotFound";

export default function App() {
  return (
    <ReportProvider>
      <HashRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route index element={<Home />} />
            <Route path="/diagnostic" element={<Diagnostic />} />
            <Route path="/tool-finder" element={<ToolFinder />} />
            <Route path="/report" element={<Report />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </HashRouter>
    </ReportProvider>
  );
}
