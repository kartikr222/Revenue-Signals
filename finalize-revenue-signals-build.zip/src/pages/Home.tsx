import { Link } from "react-router-dom";
import { ArrowRight, Eye, Gauge, ShieldAlert, Target, TrendingUp, Wrench } from "lucide-react";
import { BRAND } from "../brand/constants";
import { CATEGORIES } from "../lib/questions";
import { LogoCircle } from "../components/Logo";

const FEATURES = [
  {
    icon: Gauge,
    title: "Signal Scoring",
    detail: "Every category of revenue health is scored 0-100 with a clear Strong / Moderate / Weak verdict.",
  },
  {
    icon: ShieldAlert,
    title: "Confidence Rating",
    detail: "We tell you how much to trust the diagnostic itself based on completeness and verified evidence.",
  },
  {
    icon: Eye,
    title: "Evidence & Blind Spots",
    detail: "See exactly which conclusions are backed by proof — and which are gut feel wearing a confident suit.",
  },
  {
    icon: TrendingUp,
    title: "Revenue Exposure",
    detail: "A dollarized estimate of revenue currently at risk from the gaps the diagnostic surfaces.",
  },
  {
    icon: Target,
    title: "Priority Actions",
    detail: "A ranked list of the highest-leverage fixes, not a generic checklist.",
  },
  {
    icon: Wrench,
    title: "Tool Finder",
    detail: "Matched tooling recommendations for every weak signal, filtered to your company stage.",
  },
];

export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-brand-navy-50 via-white to-white">
        <div className="mx-auto max-w-7xl px-6 py-20 sm:py-28">
          <div className="mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand-gold-400/40 bg-brand-gold-50 px-4 py-1.5 text-xs font-semibold uppercase tracking-wide text-brand-gold-600">
              <LogoCircle className="h-4 w-4" />
              {BRAND.companyName}
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-brand-ink sm:text-6xl">
              {BRAND.productName}
            </h1>
            <p className="mt-6 text-lg leading-relaxed text-brand-slate-700 sm:text-xl">
              {BRAND.tagline} A ten-minute executive diagnostic that scores your revenue
              signals, exposes contradictions, and tells you exactly where money is leaking.
            </p>
            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link
                to="/diagnostic"
                className="inline-flex items-center gap-2 rounded-full bg-brand-navy px-7 py-3.5 text-base font-semibold text-white shadow-lg shadow-brand-navy/20 brand-focus transition-transform hover:-translate-y-0.5 hover:bg-brand-ink"
              >
                Run the Diagnostic
                <ArrowRight className="h-4 w-4" />
              </Link>
              <Link
                to="/tool-finder"
                className="inline-flex items-center gap-2 rounded-full border border-brand-slate-300 bg-white px-7 py-3.5 text-base font-semibold text-brand-ink brand-focus transition-colors hover:border-brand-navy-500 hover:text-brand-navy"
              >
                Explore Tool Finder
              </Link>
            </div>
          </div>
        </div>
        <div className="pointer-events-none absolute -top-24 right-0 h-72 w-72 rounded-full bg-brand-gold-100 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 left-0 h-72 w-72 rounded-full bg-brand-navy-100 blur-3xl" />
      </section>

      {/* Categories strip */}
      <section className="border-y border-brand-slate-100 bg-white py-10">
        <div className="mx-auto max-w-7xl px-6">
          <p className="mb-6 text-center text-sm font-semibold uppercase tracking-wide text-brand-slate-500">
            Six revenue signal categories, scored in one pass
          </p>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {CATEGORIES.map((c) => (
              <div
                key={c.id}
                className="rounded-xl border border-brand-slate-100 bg-brand-slate-50 p-4 text-center"
              >
                <p className="text-sm font-semibold text-brand-ink">{c.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-7xl px-6 py-20">
        <div className="mx-auto mb-14 max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-brand-ink sm:text-4xl">
            Built for executives who are done guessing
          </h2>
          <p className="mt-4 text-brand-slate-700">
            Revenue Signals™ doesn't just survey your team — it cross-examines the answers.
          </p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div
              key={f.title}
              className="rounded-2xl border border-brand-slate-100 bg-white p-6 shadow-sm transition-shadow hover:shadow-md"
            >
              <div className="mb-4 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-brand-navy-50 text-brand-navy">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold text-brand-ink">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-brand-slate-700">{f.detail}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-brand-navy">
        <div className="mx-auto max-w-5xl px-6 py-16 text-center">
          <h2 className="text-3xl font-bold text-white sm:text-4xl">
            Get your Revenue Signals™ report today
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-brand-navy-100">
            Answer twelve questions. Get a scored, evidence-based executive report in minutes.
          </p>
          <Link
            to="/diagnostic"
            className="mt-8 inline-flex items-center gap-2 rounded-full bg-brand-gold-500 px-7 py-3.5 text-base font-semibold text-brand-ink shadow-lg brand-focus transition-transform hover:-translate-y-0.5 hover:bg-brand-gold-400"
          >
            Start Diagnostic
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}
