import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { CheckCircle2, ChevronLeft, ChevronRight } from "lucide-react";
import { CATEGORIES, QUESTIONS } from "../lib/questions";
import type { AnswerMap } from "../lib/types";
import { runDiagnostic } from "../lib/diagnosticEngine";
import { useReport } from "../state/ReportContext";

const SCALE_LABELS: Record<number, string> = {
  1: "Severe gap",
  2: "Weak",
  3: "Developing",
  4: "Solid",
  5: "Excellent",
};

export default function Diagnostic() {
  const navigate = useNavigate();
  const { setReport } = useReport();

  const [step, setStep] = useState(0); // 0 = intake, 1..N = category steps, last = review
  const [companyName, setCompanyName] = useState("");
  const [annualRevenue, setAnnualRevenue] = useState<string>("5000000");
  const [industry, setIndustry] = useState("B2B SaaS");
  const [answers, setAnswers] = useState<AnswerMap>({});

  const totalSteps = CATEGORIES.length + 1; // intake + one step per category

  const currentCategory = step >= 1 && step <= CATEGORIES.length ? CATEGORIES[step - 1] : null;
  const categoryQuestions = currentCategory
    ? QUESTIONS.filter((q) => q.category === currentCategory.id)
    : [];

  const answeredCount = Object.keys(answers).length;
  const progressPct = Math.round((answeredCount / QUESTIONS.length) * 100);

  function setAnswer(id: string, score: number, verified: boolean) {
    setAnswers((prev) => ({ ...prev, [id]: { score, verified, note: prev[id]?.note } }));
  }

  const canAdvanceIntake = companyName.trim().length > 0 && Number(annualRevenue) > 0;
  const canAdvanceCategory = currentCategory
    ? categoryQuestions.every((q) => answers[q.id])
    : true;

  function handleNext() {
    if (step < totalSteps) {
      setStep((s) => s + 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      submit();
    }
  }

  function handleBack() {
    if (step > 0) setStep((s) => s - 1);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function submit() {
    const report = runDiagnostic({
      companyName: companyName.trim() || "Your Company",
      annualRevenue: Number(annualRevenue) || 0,
      industry,
      answers,
    });
    setReport(report);
    navigate("/report");
  }

  const isLastStep = step === totalSteps;

  return (
    <div className="mx-auto max-w-3xl px-6 py-14">
      <div className="mb-8">
        <p className="text-sm font-semibold uppercase tracking-wide text-brand-gold-600">
          Revenue Signals™ Diagnostic
        </p>
        <h1 className="mt-1 text-3xl font-bold text-brand-ink">
          {step === 0 ? "Tell us about your business" : isLastStep ? "Review & generate report" : currentCategory?.label}
        </h1>
        {currentCategory && (
          <p className="mt-2 text-brand-slate-700">{currentCategory.description}</p>
        )}
      </div>

      {/* Progress bar */}
      <div className="mb-10 h-2 w-full overflow-hidden rounded-full bg-brand-slate-100">
        <div
          className="h-full rounded-full bg-brand-gold-500 transition-all"
          style={{ width: `${Math.max(6, (step / totalSteps) * 100)}%` }}
        />
      </div>

      {step === 0 && (
        <IntakeStep
          companyName={companyName}
          setCompanyName={setCompanyName}
          annualRevenue={annualRevenue}
          setAnnualRevenue={setAnnualRevenue}
          industry={industry}
          setIndustry={setIndustry}
        />
      )}

      {currentCategory && (
        <div className="space-y-8">
          {categoryQuestions.map((q) => (
            <QuestionCard
              key={q.id}
              prompt={q.prompt}
              helper={q.helper}
              value={answers[q.id]}
              onChange={(score, verified) => setAnswer(q.id, score, verified)}
            />
          ))}
        </div>
      )}

      {isLastStep && (
        <ReviewStep
          companyName={companyName}
          annualRevenue={annualRevenue}
          industry={industry}
          answeredCount={answeredCount}
          total={QUESTIONS.length}
          progressPct={progressPct}
        />
      )}

      <div className="mt-12 flex items-center justify-between">
        <button
          onClick={handleBack}
          disabled={step === 0}
          className="inline-flex items-center gap-1 rounded-full border border-brand-slate-300 px-5 py-2.5 text-sm font-semibold text-brand-ink disabled:cursor-not-allowed disabled:opacity-40 brand-focus"
        >
          <ChevronLeft className="h-4 w-4" /> Back
        </button>
        <button
          onClick={handleNext}
          disabled={step === 0 ? !canAdvanceIntake : !canAdvanceCategory}
          className="inline-flex items-center gap-2 rounded-full bg-brand-navy px-6 py-2.5 text-sm font-semibold text-white shadow-sm disabled:cursor-not-allowed disabled:opacity-40 brand-focus hover:bg-brand-ink"
        >
          {isLastStep ? "Generate Report" : "Continue"}
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

function IntakeStep({
  companyName,
  setCompanyName,
  annualRevenue,
  setAnnualRevenue,
  industry,
  setIndustry,
}: {
  companyName: string;
  setCompanyName: (v: string) => void;
  annualRevenue: string;
  setAnnualRevenue: (v: string) => void;
  industry: string;
  setIndustry: (v: string) => void;
}) {
  return (
    <div className="space-y-6 rounded-2xl border border-brand-slate-100 bg-white p-6 shadow-sm">
      <div>
        <label className="mb-1.5 block text-sm font-semibold text-brand-ink">Company name</label>
        <input
          value={companyName}
          onChange={(e) => setCompanyName(e.target.value)}
          placeholder="Acme Industries"
          className="w-full rounded-lg border border-brand-slate-300 px-4 py-2.5 text-brand-ink brand-focus"
        />
      </div>
      <div>
        <label className="mb-1.5 block text-sm font-semibold text-brand-ink">
          Annual revenue (USD)
        </label>
        <input
          type="number"
          min={0}
          value={annualRevenue}
          onChange={(e) => setAnnualRevenue(e.target.value)}
          placeholder="5000000"
          className="w-full rounded-lg border border-brand-slate-300 px-4 py-2.5 text-brand-ink brand-focus"
        />
        <p className="mt-1 text-xs text-brand-slate-500">
          Used to estimate dollarized revenue exposure in your report.
        </p>
      </div>
      <div>
        <label className="mb-1.5 block text-sm font-semibold text-brand-ink">Industry</label>
        <select
          value={industry}
          onChange={(e) => setIndustry(e.target.value)}
          className="w-full rounded-lg border border-brand-slate-300 bg-white px-4 py-2.5 text-brand-ink brand-focus"
        >
          {["B2B SaaS", "Professional Services", "E-commerce", "Manufacturing", "Healthcare", "Financial Services", "Other"].map(
            (opt) => (
              <option key={opt} value={opt}>
                {opt}
              </option>
            )
          )}
        </select>
      </div>
    </div>
  );
}

function QuestionCard({
  prompt,
  helper,
  value,
  onChange,
}: {
  prompt: string;
  helper?: string;
  value?: { score: number; verified: boolean };
  onChange: (score: number, verified: boolean) => void;
}) {
  return (
    <div className="rounded-2xl border border-brand-slate-100 bg-white p-6 shadow-sm">
      <p className="text-base font-semibold text-brand-ink">{prompt}</p>
      {helper && <p className="mt-1 text-sm text-brand-slate-500">{helper}</p>}

      <div className="mt-5 grid grid-cols-5 gap-2">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            type="button"
            onClick={() => onChange(n, value?.verified ?? false)}
            className={`rounded-lg border px-2 py-3 text-center text-xs font-semibold transition-colors brand-focus ${
              value?.score === n
                ? "border-brand-navy bg-brand-navy text-white"
                : "border-brand-slate-300 text-brand-slate-700 hover:border-brand-navy-500"
            }`}
          >
            <span className="block text-sm">{n}</span>
            <span className="mt-0.5 block text-[10px] font-medium opacity-80">
              {SCALE_LABELS[n]}
            </span>
          </button>
        ))}
      </div>

      <label className="mt-4 flex cursor-pointer items-center gap-2 text-sm text-brand-slate-700">
        <input
          type="checkbox"
          checked={value?.verified ?? false}
          onChange={(e) => onChange(value?.score ?? 0, e.target.checked)}
          disabled={!value?.score}
          className="h-4 w-4 rounded border-brand-slate-300 text-brand-navy brand-focus"
        />
        This is backed by a documented process, report, or system — not just a gut feeling.
      </label>
    </div>
  );
}

function ReviewStep({
  companyName,
  annualRevenue,
  industry,
  answeredCount,
  total,
  progressPct,
}: {
  companyName: string;
  annualRevenue: string;
  industry: string;
  answeredCount: number;
  total: number;
  progressPct: number;
}) {
  const revenueNum = useMemo(() => Number(annualRevenue) || 0, [annualRevenue]);
  return (
    <div className="rounded-2xl border border-brand-slate-100 bg-white p-6 shadow-sm">
      <div className="flex items-center gap-3">
        <CheckCircle2 className="h-6 w-6 text-signal-strong" />
        <p className="font-semibold text-brand-ink">Ready to generate your report</p>
      </div>
      <dl className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div>
          <dt className="text-xs uppercase tracking-wide text-brand-slate-500">Company</dt>
          <dd className="font-medium text-brand-ink">{companyName || "—"}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-brand-slate-500">Annual revenue</dt>
          <dd className="font-medium text-brand-ink">${revenueNum.toLocaleString()}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-brand-slate-500">Industry</dt>
          <dd className="font-medium text-brand-ink">{industry}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-wide text-brand-slate-500">Questions answered</dt>
          <dd className="font-medium text-brand-ink">
            {answeredCount} / {total} ({progressPct}%)
          </dd>
        </div>
      </dl>
    </div>
  );
}
