import { useMemo, useState } from "react";
import { Search, Wrench } from "lucide-react";
import { TOOLS } from "../lib/toolsData";
import { CATEGORIES } from "../lib/questions";
import type { CategoryId } from "../lib/types";
import { useReport } from "../state/ReportContext";

const STAGES = ["Early", "Growth", "Scale"] as const;

export default function ToolFinder() {
  const { report } = useReport();
  const weakestCategory = useMemo(() => {
    if (!report) return null;
    return [...report.categoryResults].sort((a, b) => a.rawScore - b.rawScore)[0]?.category.id ?? null;
  }, [report]);

  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<CategoryId | "all">(weakestCategory ?? "all");
  const [stage, setStage] = useState<(typeof STAGES)[number] | "all">("all");

  const filtered = TOOLS.filter((tool) => {
    const matchesQuery =
      query.trim().length === 0 ||
      tool.name.toLowerCase().includes(query.toLowerCase()) ||
      tool.summary.toLowerCase().includes(query.toLowerCase()) ||
      tool.tags.some((t) => t.toLowerCase().includes(query.toLowerCase()));
    const matchesCategory = category === "all" || tool.category === category;
    const matchesStage = stage === "all" || tool.stage === stage;
    return matchesQuery && matchesCategory && matchesStage;
  });

  return (
    <div className="mx-auto max-w-6xl px-6 py-14">
      <div className="mb-8 flex items-center gap-3">
        <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-brand-navy-50 text-brand-navy">
          <Wrench className="h-6 w-6" />
        </div>
        <div>
          <p className="text-sm font-semibold uppercase tracking-wide text-brand-gold-600">
            Built-in Tool Finder
          </p>
          <h1 className="text-3xl font-bold text-brand-ink">Find tooling for every revenue signal</h1>
        </div>
      </div>

      {report && weakestCategory && (
        <div className="mb-8 rounded-xl border border-brand-gold-400/30 bg-brand-gold-50 p-4 text-sm text-brand-ink">
          Based on your latest report, <strong>{CATEGORIES.find((c) => c.id === weakestCategory)?.label}</strong> is
          your weakest signal. We've pre-filtered recommendations below.
        </div>
      )}

      {/* Filters */}
      <div className="grid gap-4 rounded-2xl border border-brand-slate-100 bg-white p-5 shadow-sm sm:grid-cols-3">
        <div className="relative sm:col-span-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-brand-slate-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search tools..."
            className="w-full rounded-lg border border-brand-slate-300 py-2.5 pl-9 pr-3 text-sm brand-focus"
          />
        </div>
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value as CategoryId | "all")}
          className="rounded-lg border border-brand-slate-300 px-3 py-2.5 text-sm brand-focus"
        >
          <option value="all">All categories</option>
          {CATEGORIES.map((c) => (
            <option key={c.id} value={c.id}>
              {c.label}
            </option>
          ))}
        </select>
        <select
          value={stage}
          onChange={(e) => setStage(e.target.value as (typeof STAGES)[number] | "all")}
          className="rounded-lg border border-brand-slate-300 px-3 py-2.5 text-sm brand-focus"
        >
          <option value="all">All stages</option>
          {STAGES.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {/* Results */}
      <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((tool) => (
          <div key={tool.id} className="flex flex-col rounded-2xl border border-brand-slate-100 bg-white p-6 shadow-sm">
            <div className="flex items-center justify-between gap-2">
              <h3 className="font-semibold text-brand-ink">{tool.name}</h3>
              <span className="rounded-full bg-brand-navy-50 px-2.5 py-1 text-xs font-semibold text-brand-navy">
                {tool.stage}
              </span>
            </div>
            <p className="mt-2 text-xs font-semibold uppercase tracking-wide text-brand-gold-600">
              {CATEGORIES.find((c) => c.id === tool.category)?.label}
            </p>
            <p className="mt-2 flex-1 text-sm text-brand-slate-700">{tool.summary}</p>
            <p className="mt-3 text-xs text-brand-slate-500">
              <strong className="text-brand-slate-700">Best for:</strong> {tool.bestFor}
            </p>
            <div className="mt-4 flex flex-wrap gap-1.5">
              {tool.tags.map((t) => (
                <span key={t} className="rounded-full bg-brand-slate-100 px-2.5 py-1 text-[11px] font-medium text-brand-slate-700">
                  {t}
                </span>
              ))}
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <p className="col-span-full rounded-xl border border-brand-slate-100 bg-white p-8 text-center text-sm text-brand-slate-500">
            No tools match those filters. Try broadening your search.
          </p>
        )}
      </div>
    </div>
  );
}
