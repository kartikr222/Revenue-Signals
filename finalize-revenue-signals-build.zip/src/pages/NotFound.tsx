import { Link } from "react-router-dom";
import { Home } from "lucide-react";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-xl flex-col items-center justify-center px-6 text-center">
      <p className="text-sm font-semibold uppercase tracking-wide text-brand-gold-600">404</p>
      <h1 className="mt-2 text-3xl font-bold text-brand-ink">Page not found</h1>
      <p className="mt-3 text-brand-slate-600">
        The page you're looking for doesn't exist or may have moved.
      </p>
      <Link
        to="/"
        className="mt-6 inline-flex items-center gap-2 rounded-full bg-brand-navy px-6 py-3 text-sm font-semibold text-white brand-focus hover:bg-brand-ink"
      >
        <Home className="h-4 w-4" /> Back to home
      </Link>
    </div>
  );
}
