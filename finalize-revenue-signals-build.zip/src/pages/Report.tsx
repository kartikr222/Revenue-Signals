import { Link, Navigate } from "react-router-dom";
import {
  AlertTriangle,
  ArrowRight,
  BadgeCheck,
  Eye,
  Gauge,
  RotateCcw,
  ShieldAlert,
  Target,
} from "lucide-react";
import { useReport } from "../state/ReportContext";
import type { CategoryResult } from "../lib/types";

function scoreColor(label: CategoryResult["label"]) {
  if (label === "Strong") return "text-signal-strong bg-signal-strong/10";
  if (label === "Moderate") return "text-signal-moderate bg-signal-moderate/10";
  return "text-signal-weak bg-signal-weak/10";
}

function impactColor(impact: "High" | "Medium" | "Low") {
  if (impact === "High") return "bg-signal-weak/10 text-signal-weak";
  if (impact === "Medium") return "bg-signal-moderate/10 text-signal-moderate";
  return "bg-signal-strong/10 text-signal-strong";
}

export default function Report() {
  const { report, clearReport } = useReport();

  if (!report) {
    return <Navigate to="/diagnostic" replace />;
  }

  const { inputs, overallScore, confidence, categoryResults, evidence, contradictions, blindSpots, revenueExposure, priorityActions } =
    report;

  return (
    <div className="mx-auto max-w-5xl px-6 py-14">
      {/* Header */}
      <div className="mb-10 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
        <div>
          <p className="text-sm font-semibold uppercase tracking-wide text-brand-gold-600">
            Revenue Signals™ Executive Report
          </p>
          <h1 className="mt-1 text-3xl font-bold text-brand-ink">{inputs.companyName}</h1>
          <p className="mt-1 text-brand-slate-600">
            {inputs.industry} · ${inputs.annualRevenue.toLocaleString()} annual revenue
          </p>
        </div>
        <Link
          to="/diagnostic"
          onClick={clearReport}
          className="inline-flex items-center gap-2 rounded-full border border-brand-slate-300 px-5 py-2.5 text-sm font-semibold text-brand-ink brand-focus hover:border-brand-navy-500"
        >
          <RotateCcw className="h-4 w-4" /> Retake diagnostic
        </Link>
      </div>

      {/* Top metrics */}
      <div className="grid gap-5 sm:grid-cols-3">
        <MetricCard
          icon={Gauge}
          label="Overall Revenue Signal Score"
          value={`${overallScore}/100`}
          sub={overallScore >= 72 ? "Strong" : overallScore >= 45 ? "Moderate" : "Weak"}
        />
        <MetricCard
          icon={ShieldAlert}
          label="Diagnostic Confidence"
          value={`${confidence}%`}
          sub={confidence >= 70 ? "High confidence" : confidence >= 45 ? "Moderate confidence" : "Low confidence"}
        />
        <MetricCard
          icon={AlertTriangle}
          label="Estimated Revenue Exposure"
          value={`$${revenueExposure.toLocaleString()}`}
          sub="Potential revenue at risk / year"
          accent
        />
      </div>

      {/* Category scores */}
      <section className="mt-14">
        <h2 className="text-xl font-bold text-brand-ink">Signal Scores by Category</h2>
        <div className="mt-5 space-y-4">
          {categoryResults.map((r) => (
            <div key={r.category.id} className="rounded-xl border border-brand-slate-100 bg-white p-5 shadow-sm">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-semibold text-brand-ink">{r.category.label}</p>
                  <p className="text-sm text-brand-slate-500">{r.category.description}</p>
                </div>
                <span className={`rounded-full px-3 py-1 text-xs font-bold ${scoreColor(r.label)}`}>
                  {r.label} · {r.rawScore}/100
                </span>
              </div>
              <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-brand-slate-100">
                <div
                  className="h-full rounded-full bg-brand-navy"
                  style={{ width: `${r.rawScore}%` }}
                />
              </div>
              <p className="mt-2 text-xs text-brand-slate-500">
                {Math.round(r.verifiedRatio * 100)}% of responses backed by verifiable evidence.
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Evidence */}
      <section className="mt-14">
        <div className="mb-5 flex items-center gap-2">
          <Eye className="h-5 w-5 text-brand-navy" />
          <h2 className="text-xl font-bold text-brand-ink">Evidence</h2>
        </div>
        <ul className="space-y-3">
          {evidence.map((e, i) => (
            <li key={i} className="rounded-lg border border-brand-slate-100 bg-white p-4 text-sm text-brand-slate-700 shadow-sm">
              {e.summary}
            </li>
          ))}
        </ul>
      </section>

      {/* Contradictions */}
      <section className="mt-14">
        <div className="mb-5 flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-signal-weak" />
          <h2 className="text-xl font-bold text-brand-ink">Contradictions</h2>
        </div>
        {contradictions.length === 0 ? (
          <p className="rounded-lg border border-brand-slate-100 bg-white p-4 text-sm text-brand-slate-600 shadow-sm">
            No material contradictions were detected across your responses.
          </p>
        ) : (
          <ul className="space-y-3">
            {contradictions.map((c, i) => (
              <li key={i} className="rounded-lg border border-signal-weak/20 bg-signal-weak/5 p-4 shadow-sm">
                <p className="font-semibold text-brand-ink">{c.title}</p>
                <p className="mt-1 text-sm text-brand-slate-700">{c.detail}</p>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Blind spots */}
      <section className="mt-14">
        <div className="mb-5 flex items-center gap-2">
          <ShieldAlert className="h-5 w-5 text-brand-gold-600" />
          <h2 className="text-xl font-bold text-brand-ink">Blind Spots</h2>
        </div>
        {blindSpots.length === 0 ? (
          <p className="rounded-lg border border-brand-slate-100 bg-white p-4 text-sm text-brand-slate-600 shadow-sm">
            No significant blind spots detected — your confidence is well supported by evidence.
          </p>
        ) : (
          <ul className="space-y-3">
            {blindSpots.map((b, i) => (
              <li key={i} className="rounded-lg border border-brand-gold-400/30 bg-brand-gold-50 p-4 shadow-sm">
                <p className="font-semibold text-brand-ink">{b.title}</p>
                <p className="mt-1 text-sm text-brand-slate-700">{b.detail}</p>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Priority actions */}
      <section className="mt-14">
        <div className="mb-5 flex items-center gap-2">
          <Target className="h-5 w-5 text-brand-navy" />
          <h2 className="text-xl font-bold text-brand-ink">Priority Actions</h2>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {priorityActions.map((a, i) => (
            <div key={i} className="rounded-xl border border-brand-slate-100 bg-white p-5 shadow-sm">
              <div className="flex items-center justify-between gap-2">
                <span className={`rounded-full px-2.5 py-1 text-xs font-bold ${impactColor(a.impact)}`}>
                  {a.impact} impact
                </span>
                <span className="text-xs font-semibold text-brand-slate-500">
                  ~${a.estimatedRecovery.toLocaleString()} recoverable
                </span>
              </div>
              <p className="mt-3 font-semibold text-brand-ink">{a.title}</p>
              <p className="mt-1 text-sm text-brand-slate-700">{a.detail}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA to tool finder */}
      <section className="mt-16 rounded-2xl bg-brand-navy p-8 text-center">
        <div className="mx-auto flex max-w-xl flex-col items-center gap-3">
          <BadgeCheck className="h-8 w-8 text-brand-gold-400" />
          <h2 className="text-2xl font-bold text-white">Close the gaps we just found</h2>
          <p className="text-brand-navy-100">
            Use Tool Finder to see recommended tooling matched to your weakest revenue signals.
          </p>
          <Link
            to="/tool-finder"
            className="mt-2 inline-flex items-center gap-2 rounded-full bg-brand-gold-500 px-6 py-3 text-sm font-semibold text-brand-ink brand-focus hover:bg-brand-gold-400"
          >
            Open Tool Finder <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}

function MetricCard({
  icon: Icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: typeof Gauge;
  label: string;
  value: string;
  sub: string;
  accent?: boolean;
}) {
  return (
    <div
      className={`rounded-2xl border p-6 shadow-sm ${
        accent ? "border-brand-gold-400/40 bg-brand-gold-50" : "border-brand-slate-100 bg-white"
      }`}
    >
      <div className="mb-3 inline-flex h-10 w-10 items-center justify-center rounded-lg bg-brand-navy-50 text-brand-navy">
        <Icon className="h-5 w-5" />
      </div>
      <p className="text-xs font-semibold uppercase tracking-wide text-brand-slate-500">{label}</p>
      <p className="mt-1 text-3xl font-bold text-brand-ink">{value}</p>
      <p className="mt-1 text-sm text-brand-slate-600">{sub}</p>
    </div>
  );
}
