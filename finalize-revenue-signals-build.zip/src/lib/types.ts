export type CategoryId =
  | "pipeline"
  | "forecast"
  | "retention"
  | "process"
  | "data"
  | "alignment";

export interface DiagnosticQuestion {
  id: string;
  category: CategoryId;
  prompt: string;
  helper?: string;
}

export interface CategoryMeta {
  id: CategoryId;
  label: string;
  description: string;
  weight: number; // relative weight toward overall revenue exposure
}

export interface QuestionAnswer {
  score: number; // 1-5 self-rated confidence/maturity
  verified: boolean; // is there documented/systemic evidence, or just a gut feeling
  note?: string;
}

export type AnswerMap = Record<string, QuestionAnswer>;

export interface DiagnosticInputs {
  companyName: string;
  annualRevenue: number;
  industry: string;
  answers: AnswerMap;
}

export interface CategoryResult {
  category: CategoryMeta;
  rawScore: number; // 0-100
  verifiedRatio: number; // 0-1, share of answers backed by evidence
  label: "Strong" | "Moderate" | "Weak";
}

export interface Contradiction {
  title: string;
  detail: string;
  categories: CategoryId[];
}

export interface BlindSpot {
  title: string;
  detail: string;
  category: CategoryId;
}

export interface PriorityAction {
  title: string;
  detail: string;
  category: CategoryId;
  impact: "High" | "Medium" | "Low";
  estimatedRecovery: number;
}

export interface DiagnosticReport {
  overallScore: number; // 0-100
  confidence: number; // 0-100
  categoryResults: CategoryResult[];
  evidence: { category: CategoryId; summary: string }[];
  contradictions: Contradiction[];
  blindSpots: BlindSpot[];
  revenueExposure: number; // dollars
  priorityActions: PriorityAction[];
  inputs: DiagnosticInputs;
}
