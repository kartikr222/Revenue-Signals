import type { CategoryId } from "./types";

export interface RevenueTool {
  id: string;
  name: string;
  category: CategoryId;
  stage: "Early" | "Growth" | "Scale";
  summary: string;
  bestFor: string;
  tags: string[];
}

export const TOOLS: RevenueTool[] = [
  {
    id: "pipeline-radar",
    name: "Pipeline Radar",
    category: "pipeline",
    stage: "Growth",
    summary: "Automated pipeline coverage and stale-deal detection layered on your CRM.",
    bestFor: "Teams who suspect pipeline looks healthier than it really is.",
    tags: ["coverage", "stale deals", "CRM overlay"],
  },
  {
    id: "forecast-anchor",
    name: "Forecast Anchor",
    category: "forecast",
    stage: "Scale",
    summary: "Replaces rep gut-feel forecasting with a weighted model built on historical conversion data.",
    bestFor: "Revenue leaders tired of forecast surprises each quarter.",
    tags: ["forecasting", "modeling", "accuracy"],
  },
  {
    id: "churn-sentry",
    name: "Churn Sentry",
    category: "retention",
    stage: "Growth",
    summary: "Monitors product usage and support signals to flag at-risk accounts early.",
    bestFor: "Customer success teams needing a quarter of runway before renewal risk hits.",
    tags: ["churn", "early warning", "CS"],
  },
  {
    id: "renewal-clock",
    name: "Renewal Clock",
    category: "retention",
    stage: "Early",
    summary: "Simple renewal and expansion timeline tracking with automated reminders.",
    bestFor: "Lean teams who need renewal visibility without a full CS platform.",
    tags: ["renewals", "expansion", "lightweight"],
  },
  {
    id: "stage-standard",
    name: "Stage Standard",
    category: "process",
    stage: "Early",
    summary: "Templated stage definitions and exit-criteria checklists enforced inside your CRM.",
    bestFor: "Sales orgs with inconsistent stage definitions between reps.",
    tags: ["process", "stage definitions", "enforcement"],
  },
  {
    id: "handoff-bridge",
    name: "Handoff Bridge",
    category: "process",
    stage: "Growth",
    summary: "Structured lead and account handoff workflows across marketing, sales, and CS.",
    bestFor: "Organizations losing deals in the cracks between teams.",
    tags: ["handoff", "workflow", "cross-team"],
  },
  {
    id: "data-ledger",
    name: "Data Ledger",
    category: "data",
    stage: "Scale",
    summary: "CRM hygiene scoring with duplicate detection and required-field enforcement.",
    bestFor: "Teams who don't fully trust the numbers in their own CRM.",
    tags: ["data hygiene", "CRM", "governance"],
  },
  {
    id: "definition-sync",
    name: "Definition Sync",
    category: "data",
    stage: "Early",
    summary: "A shared glossary and automated checks to keep MRR, ARR, and bookings definitions consistent.",
    bestFor: "Finance and RevOps teams reconciling conflicting revenue numbers.",
    tags: ["definitions", "reporting", "finance"],
  },
  {
    id: "alignment-room",
    name: "Alignment Room",
    category: "alignment",
    stage: "Growth",
    summary: "Structured cross-functional workshops and shared scorecards for revenue teams.",
    bestFor: "Leaders who need sales, marketing, and CS pointed at the same number.",
    tags: ["alignment", "incentives", "workshops"],
  },
  {
    id: "incentive-mirror",
    name: "Incentive Mirror",
    category: "alignment",
    stage: "Scale",
    summary: "Models and compares incentive plans across teams to surface misaligned motivators.",
    bestFor: "Revenue operations teams redesigning compensation plans.",
    tags: ["compensation", "incentives", "modeling"],
  },
  {
    id: "pipeline-clean",
    name: "Pipeline Clean",
    category: "pipeline",
    stage: "Early",
    summary: "One-click pipeline audit flagging deals with no recent activity or missing next steps.",
    bestFor: "Smaller teams wanting a fast pipeline gut-check.",
    tags: ["audit", "activity tracking", "lightweight"],
  },
  {
    id: "forecast-pulse",
    name: "Forecast Pulse",
    category: "forecast",
    stage: "Early",
    summary: "Lightweight weekly forecast call-tracking to catch drift before quarter close.",
    bestFor: "Teams without the volume to justify a full forecasting platform yet.",
    tags: ["forecasting", "weekly cadence", "lightweight"],
  },
];
