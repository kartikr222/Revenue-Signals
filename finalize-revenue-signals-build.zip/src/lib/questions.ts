import type { CategoryMeta, DiagnosticQuestion } from "./types";

export const CATEGORIES: CategoryMeta[] = [
  {
    id: "pipeline",
    label: "Pipeline Visibility",
    description: "How clearly leadership can see real, qualified pipeline.",
    weight: 0.2,
  },
  {
    id: "forecast",
    label: "Forecast Accuracy",
    description: "How closely committed forecasts match closed revenue.",
    weight: 0.22,
  },
  {
    id: "retention",
    label: "Churn & Retention",
    description: "Early warning visibility into at-risk revenue and renewals.",
    weight: 0.2,
  },
  {
    id: "process",
    label: "Sales Process Discipline",
    description: "Consistency of stage definitions, qualification, and handoffs.",
    weight: 0.14,
  },
  {
    id: "data",
    label: "Data & Systems Hygiene",
    description: "Trustworthiness of the CRM and reporting data beneath every number.",
    weight: 0.14,
  },
  {
    id: "alignment",
    label: "Team Alignment",
    description: "Shared definitions and incentives across sales, marketing, and CS.",
    weight: 0.1,
  },
];

export const QUESTIONS: DiagnosticQuestion[] = [
  {
    id: "pipeline-1",
    category: "pipeline",
    prompt: "How confident are you that your open pipeline reflects real, active opportunities?",
    helper: "Not aspirational deals or stale records.",
  },
  {
    id: "pipeline-2",
    category: "pipeline",
    prompt: "Can you see pipeline coverage by segment and rep without manual spreadsheet work?",
  },
  {
    id: "forecast-1",
    category: "forecast",
    prompt: "Over the last four quarters, how closely has committed forecast matched actual closed revenue?",
  },
  {
    id: "forecast-2",
    category: "forecast",
    prompt: "How confident are you in forecast submissions from individual reps vs. roll-up math?",
  },
  {
    id: "retention-1",
    category: "retention",
    prompt: "How early can you identify an account that is likely to churn or downgrade?",
  },
  {
    id: "retention-2",
    category: "retention",
    prompt: "How reliable is your visibility into renewal timing and expansion revenue?",
  },
  {
    id: "process-1",
    category: "process",
    prompt: "Do all reps use the same stage definitions and exit criteria consistently?",
  },
  {
    id: "process-2",
    category: "process",
    prompt: "How disciplined is the handoff between marketing, sales, and customer success?",
  },
  {
    id: "data-1",
    category: "data",
    prompt: "How much do you trust the data quality in your CRM without manual verification?",
  },
  {
    id: "data-2",
    category: "data",
    prompt: "Are revenue definitions (MRR, ARR, bookings) consistent across every system and team?",
  },
  {
    id: "alignment-1",
    category: "alignment",
    prompt: "Do sales, marketing, and CS leadership agree on what counts as a 'qualified' opportunity?",
  },
  {
    id: "alignment-2",
    category: "alignment",
    prompt: "Are incentive plans aligned toward the same revenue outcomes across teams?",
  },
];
