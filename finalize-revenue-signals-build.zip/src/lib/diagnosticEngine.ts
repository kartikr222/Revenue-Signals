import { CATEGORIES, QUESTIONS } from "./questions";
import type {
  AnswerMap,
  BlindSpot,
  CategoryResult,
  Contradiction,
  DiagnosticInputs,
  DiagnosticReport,
  PriorityAction,
} from "./types";

function scoreLabel(raw: number): "Strong" | "Moderate" | "Weak" {
  if (raw >= 72) return "Strong";
  if (raw >= 45) return "Moderate";
  return "Weak";
}

function categoryResults(answers: AnswerMap): CategoryResult[] {
  return CATEGORIES.map((category) => {
    const qs = QUESTIONS.filter((q) => q.category === category.id);
    const answered = qs.map((q) => answers[q.id]).filter(Boolean);
    const avgScore =
      answered.length > 0
        ? answered.reduce((sum, a) => sum + a.score, 0) / answered.length
        : 0;
    const verifiedRatio =
      answered.length > 0
        ? answered.filter((a) => a.verified).length / answered.length
        : 0;
    const raw = Math.round((avgScore / 5) * 100);
    return {
      category,
      rawScore: raw,
      verifiedRatio,
      label: scoreLabel(raw),
    };
  });
}

function buildEvidence(results: CategoryResult[]) {
  return results.map((r) => ({
    category: r.category.id,
    summary:
      r.verifiedRatio >= 0.5
        ? `${r.category.label}: score of ${r.rawScore}/100 backed by documented process or system evidence in ${Math.round(
            r.verifiedRatio * 100
          )}% of responses.`
        : `${r.category.label}: score of ${r.rawScore}/100 is largely self-reported, with only ${Math.round(
            r.verifiedRatio * 100
          )}% of responses backed by verifiable evidence.`,
  }));
}

function findContradictions(results: CategoryResult[]): Contradiction[] {
  const byId = Object.fromEntries(results.map((r) => [r.category.id, r]));
  const contradictions: Contradiction[] = [];

  const pipeline = byId["pipeline"];
  const forecast = byId["forecast"];
  if (pipeline && forecast && pipeline.rawScore - forecast.rawScore >= 25) {
    contradictions.push({
      title: "Pipeline confidence outpaces forecast accuracy",
      detail: `Pipeline Visibility scored ${pipeline.rawScore}/100 while Forecast Accuracy scored only ${forecast.rawScore}/100. Strong pipeline optics with weak forecast reliability usually signals inflated or unqualified deals sitting in the funnel.`,
      categories: ["pipeline", "forecast"],
    });
  }

  const data = byId["data"];
  if (data && pipeline && pipeline.rawScore >= 65 && data.rawScore <= 45) {
    contradictions.push({
      title: "High pipeline confidence resting on weak data hygiene",
      detail: `Leadership reports strong visibility into pipeline (${pipeline.rawScore}/100), but Data & Systems Hygiene scored only ${data.rawScore}/100. Visibility is only as trustworthy as the data underneath it.`,
      categories: ["pipeline", "data"],
    });
  }

  const retention = byId["retention"];
  const alignment = byId["alignment"];
  if (retention && alignment && retention.rawScore >= 65 && alignment.rawScore <= 45) {
    contradictions.push({
      title: "Retention confidence without cross-team alignment",
      detail: `Churn & Retention visibility is rated strong (${retention.rawScore}/100), yet Team Alignment is weak (${alignment.rawScore}/100). Retention signals are hard to trust when CS, sales, and marketing don't share the same definitions.`,
      categories: ["retention", "alignment"],
    });
  }

  const process = byId["process"];
  if (process && forecast && process.rawScore <= 45 && forecast.rawScore >= 65) {
    contradictions.push({
      title: "Forecast confidence despite inconsistent sales process",
      detail: `Forecast Accuracy is rated strong (${forecast.rawScore}/100) while Sales Process Discipline is weak (${process.rawScore}/100). Without consistent stage definitions, forecast accuracy is likely coincidental rather than structural.`,
      categories: ["process", "forecast"],
    });
  }

  return contradictions;
}

function findBlindSpots(results: CategoryResult[]): BlindSpot[] {
  const spots: BlindSpot[] = [];
  for (const r of results) {
    if (r.rawScore >= 60 && r.verifiedRatio < 0.5) {
      spots.push({
        title: `${r.category.label} is self-rated strong but unverified`,
        detail: `This score relies on gut feel rather than documented process, reports, or system-of-record evidence. Treat this as an assumption to pressure-test, not a confirmed strength.`,
        category: r.category.id,
      });
    }
    if (r.rawScore < 40) {
      spots.push({
        title: `${r.category.label} is a confirmed low-visibility zone`,
        detail: `Both the self-reported score and available evidence suggest this is an active blind spot that is likely masking revenue risk.`,
        category: r.category.id,
      });
    }
  }
  return spots;
}

function buildPriorityActions(
  results: CategoryResult[],
  revenue: number
): PriorityAction[] {
  const actionLibrary: Record<string, { title: string; detail: string }> = {
    pipeline: {
      title: "Audit pipeline for stale and unqualified opportunities",
      detail:
        "Run a stage-by-stage pipeline audit against hard exit criteria and purge or re-qualify anything untouched in 30+ days.",
    },
    forecast: {
      title: "Rebuild forecast methodology on verified signals",
      detail:
        "Shift forecast roll-ups from rep gut-feel to a weighted model using stage conversion history and verified deal evidence.",
    },
    retention: {
      title: "Stand up an early-warning churn signal system",
      detail:
        "Instrument usage, support, and engagement signals to flag at-risk accounts at least one full quarter before renewal.",
    },
    process: {
      title: "Standardize stage definitions and exit criteria",
      detail:
        "Document a single shared definition for every pipeline stage and enforce it through CRM validation rules.",
    },
    data: {
      title: "Run a CRM data hygiene sprint",
      detail:
        "Reconcile duplicate records, enforce required fields, and align revenue definitions (MRR/ARR/bookings) across every system.",
    },
    alignment: {
      title: "Align sales, marketing, and CS on shared definitions",
      detail:
        "Host a cross-functional working session to agree on qualified-lead criteria and shared incentive metrics.",
    },
  };

  const ranked = [...results].sort((a, b) => {
    const impactA = (100 - a.rawScore) * a.category.weight;
    const impactB = (100 - b.rawScore) * b.category.weight;
    return impactB - impactA;
  });

  return ranked.slice(0, 4).map((r) => {
    const gap = (100 - r.rawScore) / 100;
    const estimatedRecovery = Math.round(revenue * r.category.weight * gap * 0.35);
    const impact: PriorityAction["impact"] =
      r.rawScore < 45 ? "High" : r.rawScore < 70 ? "Medium" : "Low";
    const lib = actionLibrary[r.category.id];
    return {
      title: lib.title,
      detail: lib.detail,
      category: r.category.id,
      impact,
      estimatedRecovery,
    };
  });
}

export function runDiagnostic(inputs: DiagnosticInputs): DiagnosticReport {
  const results = categoryResults(inputs.answers);

  const overallScore = Math.round(
    results.reduce((sum, r) => sum + r.rawScore * r.category.weight, 0) /
      results.reduce((sum, r) => sum + r.category.weight, 0)
  );

  const answeredCount = Object.keys(inputs.answers).length;
  const completeness = Math.min(1, answeredCount / QUESTIONS.length);
  const verifiedAvg =
    results.reduce((sum, r) => sum + r.verifiedRatio, 0) / results.length;
  const confidence = Math.round((completeness * 0.6 + verifiedAvg * 0.4) * 100);

  const contradictions = findContradictions(results);
  const blindSpots = findBlindSpots(results);
  const evidence = buildEvidence(results);
  const priorityActions = buildPriorityActions(results, inputs.annualRevenue);

  const exposureFactor = 1 - overallScore / 100;
  const revenueExposure = Math.round(
    inputs.annualRevenue * exposureFactor * 0.3 +
      contradictions.length * inputs.annualRevenue * 0.01
  );

  return {
    overallScore,
    confidence,
    categoryResults: results,
    evidence,
    contradictions,
    blindSpots,
    revenueExposure,
    priorityActions,
    inputs,
  };
}
