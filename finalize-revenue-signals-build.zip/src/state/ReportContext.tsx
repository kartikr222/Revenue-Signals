import { createContext, useContext, useMemo, useState, type ReactNode } from "react";
import type { DiagnosticReport } from "../lib/types";

interface ReportContextValue {
  report: DiagnosticReport | null;
  setReport: (report: DiagnosticReport) => void;
  clearReport: () => void;
}

const ReportContext = createContext<ReportContextValue | undefined>(undefined);

const STORAGE_KEY = "revenue-signals-report";

function loadInitial(): DiagnosticReport | null {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as DiagnosticReport) : null;
  } catch {
    return null;
  }
}

export function ReportProvider({ children }: { children: ReactNode }) {
  const [report, setReportState] = useState<DiagnosticReport | null>(loadInitial);

  const value = useMemo<ReportContextValue>(
    () => ({
      report,
      setReport: (r) => {
        setReportState(r);
        try {
          sessionStorage.setItem(STORAGE_KEY, JSON.stringify(r));
        } catch {
          // ignore storage errors
        }
      },
      clearReport: () => {
        setReportState(null);
        try {
          sessionStorage.removeItem(STORAGE_KEY);
        } catch {
          // ignore
        }
      },
    }),
    [report]
  );

  return <ReportContext.Provider value={value}>{children}</ReportContext.Provider>;
}

export function useReport() {
  const ctx = useContext(ReportContext);
  if (!ctx) throw new Error("useReport must be used within a ReportProvider");
  return ctx;
}
